import sqlite3
import logging
import os
import pytz
import asyncio
from datetime import datetime, timezone, timedelta
from telegram.error import RetryAfter
from typing import List, Dict, Any, Optional, Tuple
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, BotCommand
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
    ContextTypes,
    CallbackQueryHandler,
    ConversationHandler,
)
from collections import defaultdict
import time

def parse_date(date_str: str) -> Optional[str]:
    """
    Преобразует строку даты в формат YYYY-MM-DD.
    Поддерживает форматы:
      - DD.MM.YYYY
      - DD/MM/YYYY
      - DD-MM-YYYY
      - YYYY-MM-DD
      - D.M.YYYY и т.д.
    Возвращает строку в формате YYYY-MM-DD или None при ошибке.
    """
    formats = [
        "%d.%m.%Y",
        "%d/%m/%Y",
        "%d-%m-%Y",
        "%Y-%m-%d",
        "%d.%m.%y",
        "%d/%m/%y",
        "%d-%m-%y",
    ]

    for fmt in formats:
        try:
            dt = datetime.strptime(date_str.strip(), fmt)
            return dt.strftime("%Y-%m-%d")
        except ValueError:
            continue
    return None

load_dotenv()

# === Логирование ===
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("telegram").setLevel(logging.WARNING)
logging.getLogger("telegram.ext").setLevel(logging.WARNING)

# === Конфигурация ===
TOKEN = os.getenv("TELEGRAM_TOKEN")
SUPPORT_CHAT_ID = int(os.getenv("SUPPORT_CHAT_ID"))
raw_topic_id = os.getenv("SUPPORT_TOPIC_ID")
SUPPORT_TOPIC_ID = int(raw_topic_id) if raw_topic_id and raw_topic_id.strip().isdigit() else None
REFUND_CHAT_ID = int(os.getenv("REFUND_CHAT_ID"))
REFUND_TOPIC_ID = int(os.getenv("REFUND_TOPIC_ID"))

ADMINS = []
for admin_id in os.getenv("ADMINS", "").split(","):
    admin_id = admin_id.strip()
    if admin_id:
        try:
            ADMINS.append(int(admin_id))
        except ValueError:
            logger.warning(f"Invalid admin ID: {admin_id}")

MSK = pytz.timezone('Europe/Moscow')
# состояния для ConversationHandler:
# 0 — редактирование приветствия, 1 — редактирование помощи, 2 — комментарий к ежедневному отчёту
WAITING_GREETING, WAITING_HELP, WAITING_REPORT = range(3)

# === Rate-limiting ===
USER_MESSAGE_TIMES = defaultdict(list)
RATE_LIMIT_WINDOW = 60
MAX_MESSAGES_PER_WINDOW = 5

async def safe_telegram_call(coro):
    """
    Оборачивает вызов Telegram API и автоматически повторяет при Flood control.
    """
    while True:
        try:
            return await coro
        except RetryAfter as e:
            logger.warning(f"Flood control: waiting {e.retry_after} seconds")
            await asyncio.sleep(e.retry_after + 1)  # +1 секунда на всякий случай
        except Exception as ex:
            logger.error(f"Telegram API error: {ex}")
            raise  # Пробрасываем другие ошибки

def is_rate_limited(user_id: int) -> bool:
    now = time.time()
    USER_MESSAGE_TIMES[user_id] = [t for t in USER_MESSAGE_TIMES[user_id] if now - t < RATE_LIMIT_WINDOW]
    if len(USER_MESSAGE_TIMES[user_id]) >= MAX_MESSAGES_PER_WINDOW:
        return True
    USER_MESSAGE_TIMES[user_id].append(now)
    return False

# === БД ===
def get_db_connection():
    return sqlite3.connect("support_bot.db", check_same_thread=False)

def run_migrations():
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS messages_mapping (
                user_chat_id       INTEGER,
                user_message_id    INTEGER,
                support_message_id INTEGER,
                ticket_id          INTEGER,
                PRIMARY KEY(user_chat_id, user_message_id)
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tickets (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                user_chat_id   INTEGER NOT NULL,
                username       TEXT,
                first_name     TEXT,
                status         TEXT NOT NULL DEFAULT 'open',
                created_at     TEXT NOT NULL,
                updated_at     TEXT NOT NULL,
                topic_id       INTEGER,
                closed_by      INTEGER,
                closed_at      TEXT
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS blocked_users (
                user_chat_id INTEGER PRIMARY KEY,
                blocked_at   TEXT NOT NULL,
                admin_id     INTEGER
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS bot_settings (
                setting_key   TEXT PRIMARY KEY,
                setting_value TEXT NOT NULL
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS operator_reports (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                operator_id INTEGER NOT NULL,
                date        TEXT NOT NULL,
                report_text TEXT NOT NULL,
                created_at  TEXT NOT NULL,
                UNIQUE(operator_id, date)
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS refunds (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_chat_id INTEGER NOT NULL,
                username TEXT,
                first_name TEXT,
                document_file_id TEXT NOT NULL,
                reason TEXT,
                status TEXT NOT NULL DEFAULT 'pending',
                created_at TEXT NOT NULL,
                completed_at TEXT,
                support_message_id INTEGER
            )
        """)

        ALLOWED_TABLES = {"tickets"}
        ALLOWED_COLUMNS = {"topic_id": "INTEGER", "closed_by": "INTEGER", "closed_at": "TEXT"}

        for table in ALLOWED_TABLES:
            cursor.execute(f"PRAGMA table_info({table})")
            existing_cols = {row[1] for row in cursor.fetchall()}
            for col, col_type in ALLOWED_COLUMNS.items():
                if col not in existing_cols:
                    cursor.execute(f"ALTER TABLE {table} ADD COLUMN {col} {col_type}")
                    logger.info(f"Added column {col} to {table}")

        conn.commit()

# === Ключевые слова для возврата ===
REFUND_KEYWORDS = {
    "возврат", "возвратить", "вернуть",
    "хочу вернуть", "нужно вернуть", "требую вернуть",
    "прошу вернуть", "оформи возврат", "оформите возврат", "сделай возврат", "сделайте возврат",
    "вернуть деньги", "верните деньги", "хочу вернуть деньги", "нужно вернуть деньги",
    "требую вернуть деньги", "прошу вернуть деньги", "денег нет", "возврат денег",
    "скиньте бабки", "отстегните", "отстегните деньжишей", "денюжки назад",
    "возвра", "возврать", "вернут", "вернул", "вернули", "возврат деняк",
}

def is_refund_request(text: str) -> bool:
    if not text:
        return False
    text_lower = text.lower()
    return any(kw in text_lower for kw in REFUND_KEYWORDS)

# === Настройки текста ===
DEFAULT_GREETING = (
    "👋 Приветствуем в нашей поддержке!\n\n"
    "📝 Заполняйте тикет внимательно и кратко, но максимально подробно. "
    "Помните, that это не чат с техподдержкой в реальном времени. Все тикеты обрабатываются в порядке очереди.\n\n"
    "‼️ Если вопрос связан с работой ВПН — проверьте инструкцию в боте. "
    "Если и это не помогает, тогда приложите скриншот из главного экрана приложения прокси-клиента (v2rayTun), "
    "а также информацию о вашем провайдере/операторе (в зависимости от того, с какой сети у вас наблюдаются проблемы при подключении к ВПН).\n\n"
    "⌛️ Придётся подождать некоторое время, прежде чем вы получите ответ на свой вопрос."
)

DEFAULT_HELP = (
    "🕘 Время работы поддержки: Пн - Вс, с 7:00 до 21:00 по МСК\n"
    "📝 Заполняйте тикет внимательно и кратко, но максимально подробно. "
    "Помните, что это не чат с техподдержкой в реальном времени. Все тикеты обрабатываются в порядке очереди.\n"
    "⌛️ Возможно придётся подождать некоторое время, прежде чем вы получите ответ на свой вопрос."
)

def get_setting(key: str, default: str = "") -> str:
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT setting_value FROM bot_settings WHERE setting_key = ?", (key,))
        row = cursor.fetchone()
        return row[0] if row else default

def set_setting(key: str, value: str):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("INSERT OR REPLACE INTO bot_settings (setting_key, setting_value) VALUES (?, ?)", (key, value))
        conn.commit()

def get_topic_mode() -> str:
    return get_setting("topic_mode", "per_user")

def set_topic_mode(mode: str):
    set_setting("topic_mode", mode)

def format_datetime(iso_string: str) -> str:
    try:
        dt = datetime.fromisoformat(iso_string)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        dt_msk = dt.astimezone(MSK)
        return dt_msk.strftime("%d.%m.%Y %H:%M")
    except Exception:
        return iso_string

def format_date_only(iso_string: str) -> str:
    try:
        dt = datetime.fromisoformat(iso_string)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        dt_msk = dt.astimezone(MSK)
        return dt_msk.strftime("%d.%m.%Y")
    except Exception:
        return iso_string

def get_today_date() -> str:
    now = datetime.now(MSK)
    return now.strftime("%Y-%m-%d")

def is_admin(user_id: int) -> bool:
    return user_id in ADMINS

# === Блокировки ===
def is_user_blocked(user_chat_id: int) -> bool:
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT 1 FROM blocked_users WHERE user_chat_id = ?", (user_chat_id,))
        return cursor.fetchone() is not None

def toggle_user_block(user_chat_id: int, admin_id: int) -> bool:
    with get_db_connection() as conn:
        cursor = conn.cursor()
        if is_user_blocked(user_chat_id):
            cursor.execute("DELETE FROM blocked_users WHERE user_chat_id = ?", (user_chat_id,))
            conn.commit()
            return False
        else:
            now = datetime.now(timezone.utc).isoformat()
            cursor.execute("INSERT INTO blocked_users (user_chat_id, blocked_at, admin_id) VALUES (?, ?, ?)",
                           (user_chat_id, now, admin_id))
            conn.commit()
            return True

# === Тикеты ===
def get_open_ticket(user_chat_id: int):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, topic_id FROM tickets
            WHERE user_chat_id = ? AND status = 'open'
            ORDER BY id DESC LIMIT 1
        """, (user_chat_id,))
        return cursor.fetchone()

async def create_ticket(context: ContextTypes.DEFAULT_TYPE, user_chat_id: int, username: str = None, first_name: str = None) -> tuple:
    now = datetime.now(timezone.utc).isoformat()
    topic_mode = get_topic_mode()
    topic_id = None

    if topic_mode == "per_user":
        display_name = username or first_name or f"User{user_chat_id}"
        topic_name = f"🟢 {display_name}"
        try:
            forum_topic = await safe_telegram_call(
                context.bot.create_forum_topic(chat_id=SUPPORT_CHAT_ID, name=topic_name[:128])
            )
            topic_id = forum_topic.message_thread_id
            logger.info(f"Created topic {topic_id} for user {user_chat_id}")
        except Exception as e:
            logger.error(f"Failed to create topic: {e}")

    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO tickets (user_chat_id, username, first_name, status, created_at, updated_at, topic_id)
            VALUES (?, ?, ?, 'open', ?, ?, ?)
        """, (user_chat_id, username, first_name, now, now, topic_id))
        conn.commit()
        ticket_id = cursor.lastrowid

    if topic_mode == "per_user" and topic_id:
        username_display = f"@{username}" if username else "Не указан"
        user_info = (
            f"👤 <b>Информация о пользователе</b>\n"
            f"🆔 ID: <code>{user_chat_id}</code>\n"
            f"👤 Имя: {first_name or 'Не указано'}\n"
            f"📱 Username: {username_display}\n"
            f"🎫 Тикет: #{ticket_id}"
        )
        try:
            await safe_telegram_call(
                context.bot.send_message(
                    chat_id=SUPPORT_CHAT_ID,
                    message_thread_id=topic_id,
                    text=user_info,
                    parse_mode="HTML"
                )
            )
        except Exception as e:
            logger.error(f"Failed to send user info: {e}")

    return ticket_id, topic_id

def update_ticket_status(ticket_id: int, status: str, closed_by: int = None):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        now = datetime.now(timezone.utc).isoformat()
        if status == "closed" and closed_by:
            cursor.execute("""
                UPDATE tickets
                SET status = ?, updated_at = ?, closed_by = ?, closed_at = ?
                WHERE id = ?
            """, (status, now, closed_by, now, ticket_id))
        else:
            cursor.execute("""
                UPDATE tickets
                SET status = ?, updated_at = ?, closed_by = NULL, closed_at = NULL
                WHERE id = ?
            """, (status, now, ticket_id))
        conn.commit()

async def update_topic_status(context: ContextTypes.DEFAULT_TYPE, ticket_id: int, status: str):
    topic_mode = get_topic_mode()
    if topic_mode != "per_user":
        return

    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT topic_id, username, first_name, user_chat_id FROM tickets WHERE id = ?", (ticket_id,))
        row = cursor.fetchone()
    if not row or not row[0]:
        return

    topic_id, username, first_name, user_chat_id = row
    status_emoji = "🔴" if status == "closed" else "🟢"
    display_name = username or first_name or f"User{user_chat_id}"
    topic_name = f"{status_emoji} {display_name}"

    try:
        await safe_telegram_call(
            context.bot.edit_forum_topic(chat_id=SUPPORT_CHAT_ID, message_thread_id=topic_id, name=topic_name[:128])
        )
    except Exception as e:
        logger.error(f"Failed to update topic name: {e}")

async def update_ticket_buttons(context: ContextTypes.DEFAULT_TYPE, support_message_id: int, ticket_id: int):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT user_chat_id, support_message_id FROM messages_mapping WHERE ticket_id = ?", (ticket_id,))
        messages = cursor.fetchall()

    for user_chat_id, msg_id in messages:
        if msg_id == support_message_id:
            continue
        try:
            with get_db_connection() as conn:
                c = conn.cursor()
                c.execute("SELECT status FROM tickets WHERE id = ?", (ticket_id,))
                ticket_status = c.fetchone()[0]

            keyboard = [[InlineKeyboardButton("❌ Заблокировать/Разблокировать", callback_data=f"block_{user_chat_id}")]]
            if ticket_status == "open":
                keyboard[0].append(InlineKeyboardButton("🔒 Закрыть тикет", callback_data=f"close_{ticket_id}"))
            else:
                keyboard[0].append(InlineKeyboardButton("🔓 Открыть тикет", callback_data=f"reopen_{ticket_id}"))

            reply_markup = InlineKeyboardMarkup(keyboard)
            await context.bot.edit_message_reply_markup(
                chat_id=SUPPORT_CHAT_ID,
                message_id=msg_id,
                reply_markup=reply_markup
            )
        except Exception as e:
            logger.debug(f"Failed to update buttons: {e}")

def get_ticket_by_support_message(support_message_id: int):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT ticket_id FROM messages_mapping WHERE support_message_id = ?", (support_message_id,))
        row = cursor.fetchone()
        return row[0] if row else None

def save_mapping(user_chat_id, user_message_id, support_message_id, ticket_id):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT OR REPLACE INTO messages_mapping (user_chat_id, user_message_id, support_message_id, ticket_id)
            VALUES (?, ?, ?, ?)
        """, (user_chat_id, user_message_id, support_message_id, ticket_id))
        conn.commit()

def find_user_by_support_message(support_message_id):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT user_chat_id, user_message_id, ticket_id
            FROM messages_mapping
            WHERE support_message_id = ?
        """, (support_message_id,))
        return cursor.fetchone()

def get_all_open_tickets(limit: int = 50):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, user_chat_id, username, first_name, created_at, updated_at
            FROM tickets
            WHERE status = 'open'
            ORDER BY updated_at DESC
            LIMIT ?
        """, (limit,))
        return cursor.fetchall()

def get_user_chat_id_by_ticket(ticket_id: int):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT user_chat_id FROM tickets WHERE id = ?", (ticket_id,))
        row = cursor.fetchone()
        return row[0] if row else None

def get_topic_id_by_ticket(ticket_id: int):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT topic_id FROM tickets WHERE id = ?", (ticket_id,))
        row = cursor.fetchone()
        return row[0] if row else None

# === Отчёты ===
def save_operator_report(operator_id: int, date: str, report_text: str) -> bool:
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            now = datetime.now(timezone.utc).isoformat()
            cursor.execute("""
                INSERT OR REPLACE INTO operator_reports (operator_id, date, report_text, created_at)
                VALUES (?, ?, ?, ?)
            """, (operator_id, date, report_text, now))
            conn.commit()
        return True
    except Exception as e:
        logger.error(f"Failed to save report: {e}")
        return False

def get_operator_report(operator_id: int, date: str) -> Optional[Tuple]:
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, report_text, created_at FROM operator_reports WHERE operator_id = ? AND date = ?", (operator_id, date))
        return cursor.fetchone()

def get_operator_reports_for_period(start_date: str, end_date: str) -> List[Tuple]:
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT operator_id, date, report_text, created_at FROM operator_reports
            WHERE date BETWEEN ? AND ?
            ORDER BY date DESC, created_at DESC
        """, (start_date, end_date))
        return cursor.fetchall()

def get_operator_daily_stats(operator_id: int, date: str) -> Dict[str, Any]:
    stats = {
        "total_tickets": 0,
        "closed_tickets": 0,
        "opened_tickets": 0,
        "reopened_tickets": 0,
    }
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM tickets WHERE DATE(created_at) = ?", (date,))
            stats["total_tickets"] = cursor.fetchone()[0] or 0

            cursor.execute(
                "SELECT COUNT(*) FROM tickets WHERE closed_by = ? AND DATE(closed_at) = ?",
                (operator_id, date)
            )
            stats["closed_tickets"] = cursor.fetchone()[0] or 0

            cursor.execute("""
                SELECT COUNT(*) FROM tickets
                WHERE status = 'open'
                  AND closed_at IS NOT NULL
                  AND DATE(updated_at) = ?
                  AND closed_by != ?
            """, (date, operator_id))
            stats["reopened_tickets"] = cursor.fetchone()[0] or 0

            stats["opened_tickets"] = stats["total_tickets"] - stats["closed_tickets"]

    except Exception as e:
        logger.error(f"Failed to get daily stats: {e}")
    return stats

# === Команды поддержки (декоратор для чата поддержки) ===

def require_support_chat(func):
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if update.message.chat_id != SUPPORT_CHAT_ID:
            return
        if update.message.chat.type not in ("supergroup", "group"):
            await update.message.reply_text("Эта команда доступна только в супергруппе поддержки.")
            return
        return await func(update, context)
    return wrapper

# === Команды отчётов операторов ===

@require_support_chat
async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /stats — краткая статистика оператора за сегодня."""
    today = get_today_date()
    user_id = update.effective_user.id
    stats = get_operator_daily_stats(user_id, today)
    stats_text = (
        f"📊 Ваша статистика за сегодня ({today}):\n"
        f"✅ Закрыто тикетов: {stats['closed_tickets']}\n"
        f"📥 Всего заявок: {stats['total_tickets']}\n"
        f"🔄 Открыто/переоткрыто: {stats['opened_tickets']}\n"
    )
    existing_report = get_operator_report(user_id, today)
    stats_text += f"\n📋 Отчёт за сегодня: {'✅ Оставлен' if existing_report else '❌ Не оставлен'}"
    await update.message.reply_text(stats_text)


@require_support_chat
async def daily_report_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /daily_report — подробный отчёт за день с возможностью добавить комментарий."""
    user_id = update.effective_user.id
    today = get_today_date()
    stats = get_operator_daily_stats(user_id, today)
    existing_report = get_operator_report(user_id, today)
    report_comment = existing_report[1] if existing_report else ""

    stats_text = (
        f"📊 <b>Отчёт за {today}</b>\n\n"
        f"📥 Всего заявок: {stats['total_tickets']}\n"
        f"✅ Закрыто: {stats['closed_tickets']}\n"
        f"🔄 Открыто/переоткрыто: {stats['opened_tickets']}\n"
    )

    if report_comment:
        stats_text += f"\n📝 <b>Комментарий:</b>\n{report_comment}\n"

    keyboard = []
    if existing_report:
        keyboard.append([
            InlineKeyboardButton("✏️ Редактировать комментарий", callback_data="edit_daily_comment"),
            InlineKeyboardButton("👁️ Скрыть комментарий", callback_data="hide_comment"),
        ])
    else:
        keyboard.append([InlineKeyboardButton("➕ Добавить комментарий", callback_data="add_daily_comment")])

    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(stats_text, parse_mode="HTML", reply_markup=reply_markup)
    # запоминаем контекст отчёта
    context.user_data["report_date"] = today
    context.user_data["operator_id"] = user_id


@require_support_chat
async def view_reports_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /view_reports [начало] [конец] — отчёты операторов за период (только для админов)."""
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Только админы могут просматривать отчёты за период.")
        return

    args = context.args
    today = get_today_date()

    if not args:
        start_date = (datetime.now(MSK) - timedelta(days=7)).strftime("%Y-%m-%d")
        end_date = today
    elif len(args) == 1:
        start_date = end_date = args[0]
    elif len(args) == 2:
        start_date, end_date = args[0], args[1]
    else:
        await update.message.reply_text(
            "Использование:\n"
            "/view_reports\n"
            "/view_reports YYYY-MM-DD\n"
            "/view_reports YYYY-MM-DD YYYY-MM-DD"
        )
        return

    # простая проверка формата дат YYYY-MM-DD
    try:
        datetime.strptime(start_date, "%Y-%m-%d")
        datetime.strptime(end_date, "%Y-%m-%d")
    except ValueError:
        await update.message.reply_text("❌ Неверный формат даты. Используйте YYYY-MM-DD.")
        return

    reports = get_operator_reports_for_period(start_date, end_date)
    if not reports:
        await update.message.reply_text(f"📭 Нет отчётов с {start_date} по {end_date}.")
        return

    full_text = f"📋 Отчёты с {start_date} по {end_date}:\n\n"
    for op_id, date, comment, _ in reports:
        stats = get_operator_daily_stats(op_id, date)
        name = get_operator_name(op_id)
        full_text += (
            f"👤 {name} | 📅 {date}\n"
            f"📥 Всего: {stats['total_tickets']} | ✅ Закрыто: {stats['closed_tickets']}\n"
        )
        if comment.strip():
            full_text += f"📝 {comment[:100]}...\n"
        full_text += "-" * 40 + "\n"

    await update.message.reply_text(full_text[:4000])


async def daily_report_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Callback‑обработчик кнопок add_daily_comment / edit_daily_comment / hide_comment."""
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    today = context.user_data.get("report_date")
    if not today or context.user_data.get("operator_id") != user_id:
        await query.message.reply_text("❌ Сессия устарела. Вызовите /daily_report ещё раз.")
        return

    if query.data in ("add_daily_comment", "edit_daily_comment"):
        template = (
            "Напишите краткий отчёт о проделанной работе:\n"
            "• Основные темы обращений\n"
            "• Сложные кейсы\n"
            "• Предложения\n\n"
            "(Можно оставить пустым)"
        )
        await query.message.reply_text(template)
        context.user_data["awaiting_daily_comment"] = True
        return WAITING_REPORT

    if query.data == "hide_comment":
        stats = get_operator_daily_stats(user_id, today)
        stats_text = (
            f"📊 <b>Отчёт за {today}</b>\n\n"
            f"📥 Всего заявок: {stats['total_tickets']}\n"
            f"✅ Закрыто: {stats['closed_tickets']}\n"
            f"🔄 Открыто/переоткрыто: {stats['opened_tickets']}\n"
        )
        keyboard = [[InlineKeyboardButton("➕ Добавить комментарий", callback_data="add_daily_comment")]]
        await query.edit_message_text(stats_text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def save_daily_comment(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Сохранение текстового комментария к ежедневному отчёту."""
    user_id = update.effective_user.id
    if context.user_data.get("operator_id") != user_id:
        await update.message.reply_text("❌ Вы не автор этого отчёта.")
        return ConversationHandler.END

    date = context.user_data.get("report_date")
    comment = (update.message.text or "").strip()

    if save_operator_report(user_id, date, comment):
        await update.message.reply_text("✅ Комментарий сохранён!")
    else:
        await update.message.reply_text("❌ Ошибка сохранения.")

    # Показываем обновлённый отчёт
    stats = get_operator_daily_stats(user_id, date)
    existing_report = get_operator_report(user_id, date)
    report_comment = existing_report[1] if existing_report else ""

    stats_text = (
        f"📊 <b>Отчёт за {date}</b>\n\n"
        f"📥 Всего заявок: {stats['total_tickets']}\n"
        f"✅ Закрыто: {stats['closed_tickets']}\n"
        f"🔄 Открыто/переоткрыто: {stats['opened_tickets']}\n"
    )
    if report_comment:
        stats_text += f"\n📝 <b>Комментарий:</b>\n{report_comment}\n"

    keyboard = [[InlineKeyboardButton("✏️ Редактировать", callback_data="edit_daily_comment")]]
    await update.message.reply_text(stats_text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

    context.user_data.pop("awaiting_daily_comment", None)
    return ConversationHandler.END

def get_refund_stats(start_date: str, end_date: str) -> Dict[str, Any]:
    """Возвращает статистику по возвратам за период"""
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM refunds WHERE DATE(created_at) BETWEEN ? AND ?", (start_date, end_date))
            total = cursor.fetchone()[0] or 0

            cursor.execute("SELECT COUNT(*) FROM refunds WHERE status = 'completed' AND DATE(completed_at) BETWEEN ? AND ?", (start_date, end_date))
            completed = cursor.fetchone()[0] or 0

            return {
                "total": total,
                "completed": completed,
                "pending": total - completed
            }
    except Exception as e:
        logger.error(f"Ошибка получения статистики по возвратам: {e}")
        return {"total": 0, "completed": 0, "pending": 0}

def export_refunds_to_excel(start_date: str, end_date: str, filename: str):
    """Экспортирует данные по возвратам в Excel"""
    from openpyxl import Workbook
    from openpyxl.styles import Font

    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, user_chat_id, username, first_name, reason, status, created_at, completed_at
            FROM refunds
            WHERE DATE(created_at) BETWEEN ? AND ?
            ORDER BY created_at DESC
        """, (start_date, end_date))
        rows = cursor.fetchall()

    wb = Workbook()
    ws = wb.active
    ws.title = "Возвраты"

    # Заголовки
    headers = ["ID", "User ID", "Username", "Имя", "Причина", "Статус", "Создан", "Завершён"]
    ws.append(headers)
    for cell in ws[1]:
        cell.font = Font(bold=True)

    # Данные
    for row in rows:
        ws.append([
            row[0],
            row[1],
            row[2] or "",
            row[3] or "",
            row[4] or "",
            "✅ Завершён" if row[5] == "completed" else "⏳ В обработке",
            format_datetime(row[6]),
            format_datetime(row[7]) if row[7] else ""
        ])

    wb.save(filename)

def get_operator_name(operator_id: int) -> str:
    return f"Оператор {operator_id}"

# === НОВЫЕ ФУНКЦИИ ДЛЯ ВОЗВРАТОВ ===

async def handle_refund_document(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.user_data.get("awaiting_refund"):
        return

    user = update.effective_user
    message = update.message
    user_chat_id = user.id

    if is_user_blocked(user_chat_id):
        return

    document = None
    caption = ""
    if message.document:
        document = message.document
        caption = message.caption or ""
    else:
        await message.reply_text("📎 Пожалуйста, пришлите **чек как документ** (.PDF). Скриншоты не принимаются.")
        return

    # Сохраняем в БД
    now = datetime.now(timezone.utc).isoformat()
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO refunds (user_chat_id, username, first_name, document_file_id, reason, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (user_chat_id, user.username, user.first_name, document.file_id, caption, now))
        conn.commit()
        refund_id = cursor.lastrowid

    # Отправляем в чат возвратов → В ТОПИК!
    user_info = (
        f"🆔 <b>ID:</b> <code>{user_chat_id}</code>\n"
        f"👤 <b>Имя:</b> {user.first_name or '—'}\n"
        f"📱 <b>Username:</b> @{user.username if user.username else '—'}\n"
        f"🎫 <b>Заявка на возврат #{refund_id}</b>\n"
        f"📝 <b>Причина:</b> {caption or 'Не указана'}"
    )

    try:
        sent_msg = await safe_telegram_call(
            context.bot.send_document(
                chat_id=REFUND_CHAT_ID,
                message_thread_id=REFUND_TOPIC_ID,
                document=document.file_id,
                caption=user_info,
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("✅ Выполнено", callback_data=f"refund_complete_{refund_id}")
                ]])
            )
        )
    except Exception as e:
        logger.error(f"Failed to send refund to topic: {e}")
        await message.reply_text("❌ Не удалось отправить заявку. Возможно, топик удалён или бот не имеет прав.")
        return

    # Сохраняем ID сообщения
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE refunds SET support_message_id = ? WHERE id = ?", (sent_msg.message_id, refund_id))
        conn.commit()

    await message.reply_text("✅ Заявка на возврат отправлена. Средства будут возвращены в течение 5–10 рабочих дней.")
    context.user_data.pop("awaiting_refund", None)

async def refund_complete_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        await query.answer("⛔ Только админы могут подтверждать возвраты.", show_alert=True)
        return

    try:
        refund_id = int(query.data.split("_")[2])
    except (IndexError, ValueError):
        return

    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT user_chat_id, support_message_id, status FROM refunds WHERE id = ?", (refund_id,))
        row = cursor.fetchone()
    if not row or row[2] == "completed":
        await query.answer("⚠️ Возврат уже обработан.", show_alert=True)
        return

    user_chat_id, support_msg_id, _ = row
    now = datetime.now(timezone.utc).isoformat()

    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE refunds SET status = 'completed', completed_at = ? WHERE id = ?", (now, refund_id))
        conn.commit()

    # Редактируем сообщение → 🔴 (в топике!)
    try:
        new_caption = query.message.caption.replace("🎫", "🔴").replace("Заявка", "Возврат выполнен")
        await context.bot.edit_message_caption(
            chat_id=REFUND_CHAT_ID,
            message_id=support_msg_id,
            message_thread_id=REFUND_TOPIC_ID,
            caption=new_caption,
            parse_mode="HTML",
            reply_markup=None
        )
    except Exception as e:
        logger.error(f"Failed to edit refund message: {e}")


    await query.message.reply_text(f"✅ Возврат #{refund_id} подтверждён.")

# === Хендлеры пользователя ===
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if is_user_blocked(update.effective_user.id):
        return
    greeting_text = get_setting("greeting", DEFAULT_GREETING)
    await update.message.reply_text(greeting_text)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if is_user_blocked(update.effective_user.id):
        return
    help_text = get_setting("help", DEFAULT_HELP)
    await update.message.reply_text(help_text)

async def forward_to_support(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message
    user = message.from_user
    user_chat_id = message.chat_id

    if is_user_blocked(user_chat_id):
        return

    if is_rate_limited(user_chat_id):
        await message.reply_text("⏳ Вы отправляете сообщения слишком часто. Подождите немного.")
        return

    # === ПРОВЕРКА НА ВОЗВРАТ ===
    if message.text and is_refund_request(message.text):
        context.user_data["awaiting_refund"] = True
        await message.reply_text(
            "📄 Пожалуйста, пришлите:\n"
            "1. Чек оплаты **в виде документа** (PDF, JPG как файл — скриншоты не принимаются)\n"
            "2. Укажите причину возврата в подписи к файлу"
        )
        return

    # === ОСТАЛЬНАЯ ЛОГИКА: ОБЫЧНЫЕ ТИКЕТЫ ===
    ticket_data = get_open_ticket(user_chat_id)
    new_ticket = False
    if ticket_data is None:
        ticket_id, topic_id = await create_ticket(context, user_chat_id, user.username, user.first_name)
        new_ticket = True
        await message.reply_text(f"✅ Ваш тикет #{ticket_id} создан.")
    else:
        ticket_id, topic_id = ticket_data

    username = f"@{user.username}" if user.username else "Не указан"
    topic_mode = get_topic_mode()
    header = f"💬 {user.first_name or 'Не указано'} ({username}):"

    send_kwargs = {"chat_id": SUPPORT_CHAT_ID}
    if topic_mode == "per_user" and topic_id:
        send_kwargs["message_thread_id"] = topic_id
    elif topic_mode == "single_topic" and SUPPORT_TOPIC_ID:
        send_kwargs["message_thread_id"] = SUPPORT_TOPIC_ID

    with get_db_connection() as conn:
        c = conn.cursor()
        c.execute("SELECT status FROM tickets WHERE id = ?", (ticket_id,))
        ticket_status = c.fetchone()[0]

    keyboard = [
        [InlineKeyboardButton("❌ Заблокировать/Разблокировать", callback_data=f"block_{user_chat_id}")]
    ]
    if ticket_status == "open":
        keyboard[0].append(InlineKeyboardButton("🔒 Закрыть тикет", callback_data=f"close_{ticket_id}"))
    else:
        keyboard[0].append(InlineKeyboardButton("🔓 Открыть тикет", callback_data=f"reopen_{ticket_id}"))
    reply_markup = InlineKeyboardMarkup(keyboard)
    send_kwargs["reply_markup"] = reply_markup

    sent_message = None
    try:
        if message.photo:
            cap = message.caption or ""
            caption_text = f"{header}\n{cap}" if cap else header
            sent_message = await safe_telegram_call(
                context.bot.send_photo(photo=message.photo[-1].file_id, caption=caption_text, **send_kwargs)
            )
        elif message.video:
            cap = message.caption or ""
            caption_text = f"{header}\n{cap}" if cap else header
            sent_message = await context.bot.send_video(video=message.video.file_id, caption=caption_text, **send_kwargs)
        elif message.document:
            cap = message.caption or ""
            caption_text = f"{header}\n{cap}" if cap else header
            sent_message = await safe_telegram_call(
                context.bot.send_document(document=message.document.file_id, caption=caption_text, **send_kwargs)
            )
        elif message.voice:
            sent_message = await context.bot.send_voice(voice=message.voice.file_id, caption=header, **send_kwargs)
        elif message.audio:
            cap = message.caption or ""
            caption_text = f"{header}\n{cap}" if cap else header
            sent_message = await context.bot.send_audio(audio=message.audio.file_id, caption=caption_text, **send_kwargs)
        elif message.text:
            sent_message = await safe_telegram_call(
                context.bot.send_message(text=f"{header}\n{message.text}", **send_kwargs)
            )
        else:
            return

        if sent_message:
            save_mapping(user_chat_id, message.message_id, sent_message.message_id, ticket_id)

    except Exception as e:
        logger.error(f"Failed to forward message: {e}")

async def reply_from_support(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message
    if message.chat_id != SUPPORT_CHAT_ID or not message.reply_to_message:
        return

    found = find_user_by_support_message(message.reply_to_message.message_id)
    if not found:
        return

    user_chat_id, _, _ = found
    if is_user_blocked(user_chat_id):
        await message.reply_text("⛔️ Пользователь заблокирован.")
        return

    try:
        kwargs = {"chat_id": user_chat_id}
        if message.photo:
            kwargs.update(photo=message.photo[-1].file_id, caption=message.caption or "")
            await context.bot.send_photo(**kwargs)
        elif message.video:
            kwargs.update(video=message.video.file_id, caption=message.caption or "")
            await context.bot.send_video(**kwargs)
        elif message.document:
            kwargs.update(document=message.document.file_id, caption=message.caption or "")
            await context.bot.send_document(**kwargs)
        elif message.voice:
            kwargs.update(voice=message.voice.file_id, caption=message.caption or "")
            await context.bot.send_voice(**kwargs)
        elif message.audio:
            kwargs.update(audio=message.audio.file_id, caption=message.caption or "")
            await context.bot.send_audio(**kwargs)
        elif message.text:
            kwargs.update(text=message.text)
            await context.bot.send_message(**kwargs)
    except Exception as e:
        logger.error(f"Failed to reply to user: {e}")

# === Callbacks с проверкой прав ===
async def close_ticket_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        await query.answer("⛔ У вас нет прав.", show_alert=True)
        return

    try:
        ticket_id = int(query.data.split("_")[1])
    except (IndexError, ValueError):
        return

    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT user_chat_id, status FROM tickets WHERE id = ?", (ticket_id,))
        result = cursor.fetchone()
    if not result or result[1] == "closed":
        await query.answer("⚠️ Тикет уже закрыт!", show_alert=True)
        return

    user_chat_id, _ = result
    update_ticket_status(ticket_id, "closed", query.from_user.id)
    await update_topic_status(context, ticket_id, "closed")

    keyboard = [
        [InlineKeyboardButton("❌ Заблокировать/Разблокировать", callback_data=f"block_{user_chat_id}"),
         InlineKeyboardButton("🔓 Открыть тикет", callback_data=f"reopen_{ticket_id}")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    try:
        await query.edit_message_reply_markup(reply_markup=reply_markup)
    except:
        pass
    await update_ticket_buttons(context, query.message.message_id, ticket_id)

    operator_name = query.from_user.first_name or f"Оператор {query.from_user.id}"
    await query.message.reply_text(f"✅ Тикет #{ticket_id} закрыт оператором {operator_name}")

    if user_chat_id:
        try:
            await context.bot.send_message(chat_id=user_chat_id, text="✅ Обращение завершено.")
        except:
            pass

async def reopen_ticket_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        await query.answer("⛔ У вас нет прав.", show_alert=True)
        return

    try:
        ticket_id = int(query.data.split("_")[1])
    except (IndexError, ValueError):
        return

    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT user_chat_id, status FROM tickets WHERE id = ?", (ticket_id,))
        result = cursor.fetchone()
    if not result or result[1] == "open":
        await query.answer("⚠️ Тикет уже открыт!", show_alert=True)
        return

    user_chat_id, _ = result
    update_ticket_status(ticket_id, "open")
    await update_topic_status(context, ticket_id, "open")

    keyboard = [
        [InlineKeyboardButton("❌ Заблокировать/Разблокировать", callback_data=f"block_{user_chat_id}"),
         InlineKeyboardButton("🔒 Закрыть тикет", callback_data=f"close_{ticket_id}")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    try:
        await query.edit_message_reply_markup(reply_markup=reply_markup)
    except:
        pass
    await update_ticket_buttons(context, query.message.message_id, ticket_id)

    operator_name = query.from_user.first_name or f"Оператор {query.from_user.id}"
    await query.message.reply_text(f"♻️ Тикет #{ticket_id} открыт оператором {operator_name}")

    if user_chat_id:
        try:
            await context.bot.send_message(chat_id=user_chat_id, text="♻️ Ваше обращение снова открыто.")
        except:
            pass

async def block_user_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        await query.answer("⛔ У вас нет прав.", show_alert=True)
        return

    data = query.data
    if not data.startswith("block_"):
        return
    try:
        target_user_id = int(data.split("_")[1])
    except (IndexError, ValueError):
        return

    admin_id = query.from_user.id
    is_blocked_now = toggle_user_block(target_user_id, admin_id)

    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT username, first_name FROM tickets WHERE user_chat_id = ? ORDER BY id DESC LIMIT 1", (target_user_id,))
        res = cursor.fetchone()

    if res:
        username, first_name = res
        username_str = f"@{username}" if username else "без юзернейма"
        user_info = f"{first_name or 'Пользователь'} ({username_str})"
    else:
        user_info = f"Пользователь {target_user_id}"

    text = f"👨 {user_info}\n❗️ {'Заблокирован' if is_blocked_now else 'Разблокирован'}"
    await context.bot.send_message(
        chat_id=query.message.chat_id,
        message_thread_id=query.message.message_thread_id,
        text=text
    )

@require_support_chat
async def open_tickets_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rows = get_all_open_tickets()
    if not rows:
        await update.message.reply_text("Открытых тикетов нет ✅")
        return
    lines = ["📂 Открытые тикеты:\n"]
    for ticket_id, user_chat_id, username, first_name, created_at, updated_at in rows:
        created_fmt = format_datetime(created_at)
        username_display = f"@{username}" if username else "Не указан"
        first_name_display = first_name or "Не указано"
        lines.append(
            f"🎫 Тикет #{ticket_id}\n"
            f"👤 {first_name_display}\n"
            f"📱 {username_display}\n"
            f"🆔 ID: {user_chat_id}\n"
            f"📅 Создан: {created_fmt}\n"
        )
    text = "\n".join(lines)
    await update.message.reply_text(text)

@require_support_chat
async def close_ticket_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message
    if not message.reply_to_message:
        await message.reply_text("Команду /close нужно вызывать ответом на сообщение тикета.")
        return
    ticket_id = get_ticket_by_support_message(message.reply_to_message.message_id)
    if not ticket_id:
        await message.reply_text("Тикет не найден.")
        return
    user_chat_id = get_user_chat_id_by_ticket(ticket_id)
    update_ticket_status(ticket_id, "closed", message.from_user.id)
    await update_topic_status(context, ticket_id, "closed")
    await message.reply_text(f"✅ Тикет #{ticket_id} закрыт.")
    if user_chat_id:
        try:
            await context.bot.send_message(chat_id=user_chat_id, text="✅ Обращение завершено.")
        except:
            pass

@require_support_chat
async def reopen_ticket_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message
    if not message.reply_to_message:
        await message.reply_text("Команду /reopen нужно вызывать ответом на сообщение тикета.")
        return
    ticket_id = get_ticket_by_support_message(message.reply_to_message.message_id)
    if not ticket_id:
        await message.reply_text("Тикет не найден.")
        return
    update_ticket_status(ticket_id, "open")
    await update_topic_status(context, ticket_id, "open")
    await message.reply_text(f"♻️ Тикет #{ticket_id} снова открыт.")

@require_support_chat
async def ticket_info_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message
    if not message.reply_to_message:
        await message.reply_text("Команду /ticket нужно вызывать ответом на сообщение тикета.")
        return
    ticket_id = get_ticket_by_support_message(message.reply_to_message.message_id)
    if not ticket_id:
        await message.reply_text("Тикет не найден.")
        return

    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT user_chat_id, status, created_at, updated_at, closed_by, closed_at
            FROM tickets WHERE id = ?
        """, (ticket_id,))
        row = cursor.fetchone()
    if not row:
        await message.reply_text("Тикет не найден в базе.")
        return

    user_chat_id, status, created_at, updated_at, closed_by, closed_at = row
    created_fmt = format_datetime(created_at)
    updated_fmt = format_datetime(updated_at)
    is_blocked = is_user_blocked(user_chat_id)
    block_status = "ДА ⛔️" if is_blocked else "НЕТ ✅"
    closed_info = ""
    if closed_by and closed_at:
        closed_fmt = format_datetime(closed_at)
        closed_info = f"Закрыт оператором: {closed_by}\nВремя закрытия: {closed_fmt}\n"

    text = (
        f"📄 Тикет #{ticket_id}\n"
        f"Пользователь: {user_chat_id}\n"
        f"Статус тикета: {status}\n"
        f"Заблокирован: {block_status}\n"
        f"Создан: {created_fmt}\n"
        f"Обновлён: {updated_fmt}\n"
        f"{closed_info}"
    )
    await message.reply_text(text)

@require_support_chat
async def unblock_user_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("⛔ Только админы могут разблокировать пользователей.")
        return

    if not context.args:
        await update.message.reply_text("UsageId: /unblock <user_id>")
        return

    try:
        user_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ Неверный ID. Укажите число.")
        return

    if not is_user_blocked(user_id):
        await update.message.reply_text(f"✅ Пользователь {user_id} не заблокирован.")
        return

    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM blocked_users WHERE user_chat_id = ?", (user_id,))
        conn.commit()

    await update.message.reply_text(f"🔓 Пользователь {user_id} успешно разблокирован.")

@require_support_chat
async def refunds_report_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /refunds_report [начало] [конец] — отчёт по возвратам"""
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Только админы могут просматривать отчёты по возвратам.")
        return

    args = context.args
    today = get_today_date()

    if not args:
        start_date = (datetime.now(MSK) - timedelta(days=7)).strftime("%Y-%m-%d")
        end_date = today
    elif len(args) == 1:
        start_date = end_date = args[0]
    elif len(args) == 2:
        start_date, end_date = args[0], args[1]
    else:
        await update.message.reply_text(
            "Использование:\n/refunds_report\n/refunds_report YYYY-MM-DD\n/refunds_report YYYY-MM-DD YYYY-MM-DD"
        )
        return
    start_parsed = parse_date(start_date)
    end_parsed = parse_date(end_date)
    if start_parsed is None or end_parsed is None:
        await update.message.reply_text(
            "❌ Неверный формат даты. Поддерживаются:\n"
            "• 01.01.2026\n• 01/01/2026\n• 2026-01-01\n• 1.1.2026"
        )
        return
    start_date = start_parsed
    end_date = end_parsed

    stats = get_refund_stats(start_date, end_date)
    text = (
        f"📊 Отчёт по возвратам с {start_date} по {end_date}\n\n"
        f"📥 Всего заявок: {stats['total']}\n"
        f"✅ Завершено: {stats['completed']}\n"
        f"⏳ В обработке: {stats['pending']}"
    )
    await update.message.reply_text(text)

@require_support_chat
async def refunds_excel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /refunds_excel [начало] [конец] — экспорт в Excel"""
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Только админы могут экспортировать данные по возвратам.")
        return

    args = context.args
    today = get_today_date()

    if not args:
        start_date = (datetime.now(MSK) - timedelta(days=7)).strftime("%Y-%m-%d")
        end_date = today
    elif len(args) == 1:
        start_date = end_date = args[0]
    elif len(args) == 2:
        start_date, end_date = args[0], args[1]
    else:
        await update.message.reply_text(
            "Использование:\n/refunds_excel\n/refunds_excel YYYY-MM-DD\n/refunds_excel YYYY-MM-DD YYYY-MM-DD"
        )
        return
    start_parsed = parse_date(start_date)
    end_parsed = parse_date(end_date)

    if start_parsed is None or end_parsed is None:
        await update.message.reply_text(
            "❌ Неверный формат даты. Поддерживаются:\n"
            "• 01.01.2026\n• 01/01/2026\n• 2026-01-01\n• 1.1.2026"
        )
        return

    start_date = start_parsed
    end_date = end_parsed

    filename = f"refunds_{start_date}_to_{end_date}.xlsx"
    try:
        export_refunds_to_excel(start_date, end_date, filename)
        with open(filename, "rb") as f:
            await update.message.reply_document(
                document=f,
                caption="📎 Файл с деталями по всем заявкам на возврат"
            )
        os.remove(filename)  # удаляем временный файл
    except Exception as e:
        logger.error(f"Ошибка экспорта Excel: {e}")
        await update.message.reply_text("❌ Не удалось создать Excel-файл.")

# === АДМИНКА ===

async def admin_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        return

    back_keyboard = [[InlineKeyboardButton("◀️ В меню", callback_data="admin_back_to_menu")]]
    back_markup = InlineKeyboardMarkup(back_keyboard)

    if query.data == "admin_edit_greeting":
        current_text = get_setting("greeting", DEFAULT_GREETING)
        msg = await query.message.reply_text(
            f"👉 Введите новое приветствие:\n<b>Текущее:</b>\n{current_text}",
            parse_mode="HTML",
            reply_markup=back_markup
        )
        context.user_data['back_button_message_id'] = msg.message_id
        return WAITING_GREETING

    elif query.data == "admin_edit_help":
        current_text = get_setting("help", DEFAULT_HELP)
        msg = await query.message.reply_text(
            f"👉 Введите новую помощь:\n<b>Текущая:</b>\n{current_text}",
            parse_mode="HTML",
            reply_markup=back_markup
        )
        context.user_data['back_button_message_id'] = msg.message_id
        return WAITING_HELP

    elif query.data == "admin_toggle_mode":
        current_mode = get_topic_mode()
        new_mode = "single_topic" if current_mode == "per_user" else "per_user"
        set_topic_mode(new_mode)
        mode_text = "📁 Отдельный топик для каждого" if new_mode == "per_user" else "📂 Общий топик"
        keyboard = [
            [InlineKeyboardButton("✏️ Изменить приветствие", callback_data="admin_edit_greeting")],
            [InlineKeyboardButton("📝 Изменить информацию", callback_data="admin_edit_help")],
            # [InlineKeyboardButton(f"🔄 Режим: {mode_text}", callback_data="admin_toggle_mode")],
            [InlineKeyboardButton("📋 Просмотр отчетов", callback_data="admin_view_reports")],
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        try:
            await query.edit_message_reply_markup(reply_markup=reply_markup)
        except Exception as e:
            logger.error(f"Failed to update mode button: {e}")
        return ConversationHandler.END

    elif query.data == "admin_view_reports":
        end_date = get_today_date()
        start_date = (datetime.now(MSK) - timedelta(days=7)).strftime("%Y-%m-%d")
        reports = get_operator_reports_for_period(start_date, end_date)
        if not reports:
            msg = await query.message.reply_text("📭 Отчетов за последние 7 дней нет.", reply_markup=back_markup)
        else:
            report_text = "📋 Отчеты за последние 7 дней:\n"
            for operator_id, date, report, created_at in reports:
                formatted_date = format_date_only(date)
                report_text += f"👤 Оператор {operator_id} | 📅 {formatted_date}\n📝 {report[:150]}...\n{'-'*30}\n"
            msg = await query.message.reply_text(report_text[:4000], reply_markup=back_markup)
        context.user_data['back_button_message_id'] = msg.message_id
        return ConversationHandler.END

    elif query.data == "admin_back_to_menu":
        return await show_admin_menu(update, context)

    return ConversationHandler.END

async def show_admin_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if not is_admin(query.from_user.id):
        return ConversationHandler.END

    topic_mode = get_topic_mode()
    mode_text = "📁 Отдельный топик для каждого" if topic_mode == "per_user" else "📂 Общий топик"
    keyboard = [
        [InlineKeyboardButton("✏️ Изменить приветствие", callback_data="admin_edit_greeting")],
        [InlineKeyboardButton("📝 Изменить информацию", callback_data="admin_edit_help")],
        # [InlineKeyboardButton(f"🔄 Режим: {mode_text}", callback_data="admin_toggle_mode")],
        [InlineKeyboardButton("📋 Просмотр отчетов", callback_data="admin_view_reports")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    try:
        await query.edit_message_text("⚙️ Управление ботом", reply_markup=reply_markup)
    except:
        pass
    return ConversationHandler.END

async def save_greeting(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END
    set_setting("greeting", update.message.text)
    await update.message.reply_text("✅ Приветствие обновлено!")
    return await restore_admin_menu(update, context)

async def save_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return ConversationHandler.END
    set_setting("help", update.message.text)
    await update.message.reply_text("✅ Помощь обновлена!")
    return await restore_admin_menu(update, context)

async def restore_admin_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    topic_mode = get_topic_mode()
    mode_text = "📁 Отдельный топик для каждого" if topic_mode == "per_user" else "📂 Общий топик"
    keyboard = [
        [InlineKeyboardButton("✏️ Изменить приветствие", callback_data="admin_edit_greeting")],
        [InlineKeyboardButton("📝 Изменить информацию", callback_data="admin_edit_help")],
        # [InlineKeyboardButton(f"🔄 Режим: {mode_text}", callback_data="admin_toggle_mode")],
        [InlineKeyboardButton("📋 Просмотр отчетов", callback_data="admin_view_reports")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    menu_msg_id = context.user_data.get('admin_menu_message_id')
    menu_chat_id = context.user_data.get('admin_menu_chat_id')
    if menu_msg_id and menu_chat_id:
        try:
            await context.bot.edit_message_text(
                chat_id=menu_chat_id,
                message_id=menu_msg_id,
                text="⚙️ Управление ботом",
                reply_markup=reply_markup
            )
        except:
            pass
    back_button_msg_id = context.user_data.get('back_button_message_id')
    if back_button_msg_id and menu_chat_id:
        try:
            await context.bot.delete_message(chat_id=menu_chat_id, message_id=back_button_msg_id)
        except:
            pass
    return ConversationHandler.END

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    topic_mode = get_topic_mode()
    mode_text = "📁 Отдельный топик для каждого" if topic_mode == "per_user" else "📂 Общий топик"
    keyboard = [
        [InlineKeyboardButton("✏️ Изменить приветствие", callback_data="admin_edit_greeting")],
        [InlineKeyboardButton("📝 Изменить информацию", callback_data="admin_edit_help")],
        # [InlineKeyboardButton(f"🔄 Режим: {mode_text}", callback_data="admin_toggle_mode")],
        [InlineKeyboardButton("📋 Просмотр отчетов", callback_data="admin_view_reports")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    msg = await update.message.reply_text("⚙️ Управление ботом", reply_markup=reply_markup)
    context.user_data['admin_menu_message_id'] = msg.message_id
    context.user_data['admin_menu_chat_id'] = msg.chat_id

# === Error handler ===
async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    logger.error(f"Update {update} caused error {context.error}")

# === Main ===
def main():
    run_migrations()
    application = Application.builder().token(TOKEN).build()

    # ConversationHandler для админки
    admin_conv_handler = ConversationHandler(
        entry_points=[
            CommandHandler("admin", admin_command),
            CallbackQueryHandler(admin_callback_handler, pattern="^admin_edit_"),
            CallbackQueryHandler(admin_callback_handler, pattern="^admin_toggle_mode$"),
            CallbackQueryHandler(admin_callback_handler, pattern="^admin_view_reports$"),
        ],
        states={
            WAITING_GREETING: [MessageHandler(filters.TEXT & ~filters.COMMAND, save_greeting)],
            WAITING_HELP: [MessageHandler(filters.TEXT & ~filters.COMMAND, save_help)],
        },
        fallbacks=[
            CallbackQueryHandler(show_admin_menu, pattern="^admin_back_to_menu$")
        ],
    )

    # Хендлеры
    application.add_handler(admin_conv_handler)

    # ConversationHandler для комментария к ежедневному отчёту
    daily_report_conv = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(daily_report_callback, pattern="^(add_daily_comment|edit_daily_comment)$"),
        ],
        states={
            WAITING_REPORT: [MessageHandler(filters.TEXT & ~filters.COMMAND, save_daily_comment)],
        },
        fallbacks=[],
    )
    application.add_handler(daily_report_conv)

    application.add_handler(MessageHandler(
        filters.ChatType.PRIVATE & filters.Document.ALL,
        handle_refund_document
    ))
    application.add_handler(CallbackQueryHandler(refund_complete_callback, pattern=r"^refund_complete_\d+$"))

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("info", help_command))
    application.add_handler(CommandHandler("open_tickets", open_tickets_cmd))
    application.add_handler(CommandHandler("close", close_ticket_cmd))
    application.add_handler(CommandHandler("reopen", reopen_ticket_cmd))
    application.add_handler(CommandHandler("ticket", ticket_info_cmd))
    application.add_handler(CommandHandler("unblock", unblock_user_cmd))
    application.add_handler(CommandHandler("refunds_report", refunds_report_command))
    application.add_handler(CommandHandler("refunds_excel", refunds_excel_command))
    # новые команды отчётов операторов
    application.add_handler(CommandHandler("stats", stats_command))
    application.add_handler(CommandHandler("daily_report", daily_report_command))
    application.add_handler(CommandHandler("view_reports", view_reports_command))

    application.add_handler(CallbackQueryHandler(close_ticket_callback, pattern="^close_"))
    application.add_handler(CallbackQueryHandler(reopen_ticket_callback, pattern="^reopen_"))
    application.add_handler(CallbackQueryHandler(block_user_callback, pattern="^block_"))
    application.add_handler(CallbackQueryHandler(daily_report_callback, pattern="^hide_comment$"))

    application.add_handler(MessageHandler(filters.ChatType.PRIVATE & (filters.ALL ^ filters.COMMAND), forward_to_support))
    application.add_handler(MessageHandler(filters.REPLY, reply_from_support))
    application.add_error_handler(error_handler)

    # Настройка команд (сохранена текущая логика; при желании можно вынести в async post_init)
    bot = application.bot
    bot.set_my_commands([
        BotCommand("start", "Запустить бота"),
        BotCommand("info", "Помощь")
    ])
    bot.set_my_commands([
        BotCommand("open_tickets", "Открытые тикеты"),
        BotCommand("unblock", "Разблокировать пользователя"),
        BotCommand("admin", "Админка"),
        BotCommand("refunds_report", "Отчёт по возвратам (админ)"),
        BotCommand("refunds_excel", "Экспорт в Excel (админ)"),
        BotCommand("stats", "Статистика оператора за день"),
        BotCommand("daily_report", "Отчёт оператора за день"),
        BotCommand("view_reports", "Отчёты операторов за период (админ)"),
    ], scope={"type": "chat", "chat_id": SUPPORT_CHAT_ID})

    logger.info("Bot started")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
